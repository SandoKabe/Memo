import { createApp } from 'vue';
import App from './App.vue';

import HomePage from './components/HomePage.vue';

createApp(App).mount('#app');
