<template>
  <div class="sidebar">
    Build Sidebar
  </div>
</template>

<script>
export default {
  name: 'Build',
};
</script>

<style scoped>
  .sidebar {
    font-size: 50px;
    transform: rotate(90deg);
    color: green;
  }
</style>
